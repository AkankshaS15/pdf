package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.Login;
import com.cg.bean.Trainee;
import com.cg.dao.TraineeDao;

import com.cg.service.TraineeService;

@Controller
public class TraineeController {

	ArrayList<String> domainList = null;
	
	@Autowired
	TraineeService traineeService;

	public TraineeService getTraineeService() {
		return traineeService;
	}


	public void setTraineeService(TraineeService traineeService) {
		this.traineeService = traineeService;
	}


	@RequestMapping(value="/ShowLoginPage", method=RequestMethod.GET)
	public String displayLoginPage(Model model) {

		Login login = new Login();
		model.addAttribute("log", login);
		return "login";	
	}

	@RequestMapping(value="/validateUser", method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="log") 
	@Valid Login login, BindingResult result, Model model) {

		Login user = traineeService.validateUser(login);
		if(user!=null) {

			return "menu";
		}
		else {

			return "error"; 
		}		
	}
	
	/******************Show Add Trainee*******************/
	
	@RequestMapping(value="/addTrainee")
	public String dispRegstPage(Model model) {
		
		domainList = new ArrayList<>();
		domainList.add("Analyst");
		domainList.add("Developer");
		domainList.add("Manager");
		domainList.add("Trainer");
		
		Trainee trainee = new Trainee();
		
		model.addAttribute("add", trainee);
		model.addAttribute("dmList", domainList);
		
		return "addTrainee";	
	}
	
	
	/**************Insert.obj***************/
	@RequestMapping(value="/InsertUser")
	public String addTrainee(@ModelAttribute(value="add") 
	@Valid Trainee trainee, BindingResult result, Model model) {
		/*
		if(result.hasErrors()) {
			
			model.addAttribute("dmList", domainList);
			return "addTrainee";
		}
		else {*/
			traineeService.insertTraineeDetails(trainee);				
			return "Result";	
		
		
	}
}
 






