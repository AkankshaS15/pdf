package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.QueryMaster;
import com.cg.dao.QueryDao;
@Service
public class QueryServiceImpl implements QueryService{
	@Autowired
QueryDao queryDao=null;
	
	

	public QueryDao getQueryDao() {
		return queryDao;
	}

	public void setQueryDao(QueryDao queryDao) {
		this.queryDao = queryDao;
	}

	@Override
	public QueryMaster updateQueries(QueryMaster queryMaster) {
		
		return queryDao.updateQueries(queryMaster);
	}

	@Override
	public QueryMaster getQueryId(int query_id) {
		
		return queryDao.getQueryId(query_id);
	}

}
