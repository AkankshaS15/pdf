package com.cg.service;

import com.cg.bean.QueryMaster;

public interface QueryService {
	public QueryMaster updateQueries(QueryMaster queryMaster);
	public QueryMaster getQueryId(int query_id);
}
