package com.cg.ctrl;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.cg.bean.QueryMaster;

import com.cg.service.QueryService;

@Controller
public class QueryController {
	
	@Autowired
QueryService queryService=null;

	public QueryService getQueryService() {
		return queryService;
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}

	@RequestMapping(value="/displayId",method=RequestMethod.GET)
    public String DisplayIdPage(Model model) {
        model.addAttribute("qr", new QueryMaster());

        return "Query";
    }
	@RequestMapping(value="/findUserDetails",method=RequestMethod.POST)
    public String getQueryForm(@ModelAttribute(value="qr") QueryMaster queryMaster,Model model) {
       QueryMaster rd=queryService.getQueryId(queryMaster.getQuery_id());  
    //System.out.println(rd);
       model.addAttribute("queryInfo",rd);
        return  "QueryForm";

    }
	@RequestMapping(value="/updateUser",method=RequestMethod.POST)
    public String updateUser(@ModelAttribute(value="queryInfo")QueryMaster queryMaster,Model model) {
       QueryMaster rd=queryService.updateQueries(queryMaster) ;  
      
       //if(rd.equals(queryMaster.getQuery_id())) {
    	   model.addAttribute("qt1",rd);
       return  "Success";
//       }
//       else {
//    	return "Failure";
//       }
//     
      
        

    }
}
