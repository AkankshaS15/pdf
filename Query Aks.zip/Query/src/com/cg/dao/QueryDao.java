package com.cg.dao;

import com.cg.bean.QueryMaster;

public interface QueryDao {
	public QueryMaster updateQueries(QueryMaster queryMaster);
	public QueryMaster getQueryId(int query_id);
}
