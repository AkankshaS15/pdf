package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.QueryMaster;

@Repository
@Transactional
public class QueryDaoImpl implements QueryDao{
	@PersistenceContext
	 EntityManager entityManager=null;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public QueryMaster updateQueries(QueryMaster queryMaster) {
		//entityManager.find(QueryMaster.class,queryMaster.getQuery_id());	
		QueryMaster re=entityManager.merge(queryMaster);
		//entityManager.flush();
			return re;
	}

	@Override
	public QueryMaster getQueryId(int query_id) {
				return entityManager.find(QueryMaster.class,query_id);
	}

}
