package com.cg.dao;

import java.util.ArrayList;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Login;
import com.cg.bean.Trainee;

@Repository
@Transactional
public class TraineeDaoImpl implements TraineeDao {

	@PersistenceContext
	EntityManager entityManager = null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExixts(String usn) {

		Login usr = entityManager.find(Login.class, usn);

		if(usr!=null) {

			return true;
		}
		else {
			return false;
		}		
	}

	@Override
	public Login validateUser(Login login) {

		Login usr = entityManager.find(Login.class, login.getUserName());	
		return usr;
	}


	@Override
	public Trainee insertTraineeDetails(Trainee trainee) {

		entityManager.persist(trainee);
		entityManager.flush();
		Trainee tr = entityManager.find(Trainee.class, trainee.getTraineeId());//here getTraineeId is primary Key
		return tr  ;
	}

	@Override
	public ArrayList<Trainee> getTraineeDetails() {

		String query = "SELECT reg from Trainee reg";
		TypedQuery tq = entityManager.createQuery(query, Trainee.class);
		ArrayList<Trainee> traineeList = (ArrayList<Trainee>) tq.getResultList();

		return traineeList;
	}

	@Override
	public Trainee deleteTrainee(int traineeId) {

		Trainee trainee = entityManager.find(Trainee.class, traineeId);
		entityManager.remove(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public Trainee getTraineeDetails(int traineeId) {
		return entityManager.find(Trainee.class, traineeId);
	}

	@Override
	public Trainee updateTrainees(Trainee trainee) {
		entityManager.find(Trainee.class,trainee.getTraineeId());   
	
		Trainee tr = entityManager.merge(trainee);
		entityManager.flush();
		return tr;
	}
}
