package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.Login;
import com.cg.bean.Trainee;

public interface TraineeDao {
	public boolean isUserExixts(String usn);
	public Login validateUser(Login login);
	public Trainee insertTraineeDetails(Trainee trainee);
	public ArrayList<Trainee> getTraineeDetails();
	public Trainee deleteTrainee(int traineeId);
	public Trainee getTraineeDetails(int traineeId);
    public Trainee updateTrainees(Trainee trainee);
}
