package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.jpa.internal.EntityManagerFactoryRegistry;
import org.springframework.stereotype.Repository;

import com.cg.dto.QueryMaster;

import oracle.net.aso.q;

@Repository
@Transactional
public class QueryDAOImpl implements QueryDAO{
	
	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public QueryMaster find(int query_id) {
		return entityManager.find(QueryMaster.class, query_id);
	}

	@Override
	public QueryMaster update(QueryMaster query) {
		return entityManager.merge(query);
	}
}
