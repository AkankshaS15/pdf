package com.cg.dao;
import com.cg.dto.QueryMaster;

public interface QueryDAO {
	public QueryMaster find(int query_id);
	public QueryMaster update(QueryMaster query);
}
